﻿namespace ProgressTest1.Models
{
    public enum BookType
    {
        Horror,
        Novel,
        Fiction,

    }
}
