﻿namespace Assignment03.DTO
{
    public class DirectorRequest
    {
        public string FullName { get; set; } = null!;
        public bool Male { get; set; }
        public String Dob { get; set; } = null!;
        public string Nationality { get; set; } = null!;
        public string Description { get; set; } = null!;
    }
}
